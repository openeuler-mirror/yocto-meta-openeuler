#ifdef HAVE_BYTESWAP_H
#include_next <byteswap.h>
#endif
