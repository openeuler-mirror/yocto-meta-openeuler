#ifndef exit_failure
#define exit_failure EXIT_FAILURE
#endif
