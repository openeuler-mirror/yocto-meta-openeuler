int value(void);
int value1(void);
