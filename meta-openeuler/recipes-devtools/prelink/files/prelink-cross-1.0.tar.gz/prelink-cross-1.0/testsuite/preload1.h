int foo(int x, int y);

