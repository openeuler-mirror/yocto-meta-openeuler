extern int bar, baz, f1 (void), f2 (void);

int *barp = &bar, *bazp = &baz;
