#include "orderlib.h"

int value(void)
{
   return 3000;
}
