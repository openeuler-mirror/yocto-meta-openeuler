#define D1(n) int qvar##n;
#include "quick1lib3.c"
