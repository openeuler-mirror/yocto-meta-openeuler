#include "preload1.h"

int foo(int x, int y) {
   return 0;
}
