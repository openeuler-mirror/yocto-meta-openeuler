#include "cxx1.h"

int A::a ()
{
  return 20;
}

int A::b ()
{
  return 21;
}

int B::a ()
{
  return 22;
}

int C::a ()
{
  return 23;
}

int C::b ()
{
  return 24;
}

C c;
