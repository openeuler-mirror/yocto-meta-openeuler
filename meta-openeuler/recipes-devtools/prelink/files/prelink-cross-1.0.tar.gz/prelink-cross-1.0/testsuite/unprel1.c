extern int bar ();

int
main ()
{
  return bar () - 42;
}
