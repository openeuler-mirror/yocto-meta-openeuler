Appendix: Example System Devicetree
===================================

.. include:: under-discussion.txt

This appendix contains a draft example system devicetree illustrating several
concepts discussed in earlier chapters.

.. literalinclude:: system-device-tree.dts
   :language: DTS
