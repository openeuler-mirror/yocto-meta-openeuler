#if !defined(_EXAMPLE_H)
#define  _EXAMPLE_H 

/* Queue Example */
void test_queue(void);
/* Mutex Example */
void test_semaphore(void);
/* Binary Semaphore Example */
void test_binary_semaphore(void);
/* Software Timer Example */
void test_software_timer(void);
#endif  /*  _EXAMPLE_H   */
