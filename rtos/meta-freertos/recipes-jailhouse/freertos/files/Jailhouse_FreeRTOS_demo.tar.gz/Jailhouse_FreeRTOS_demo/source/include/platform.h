#ifndef _H_PLATFORM_
#define _H_PLATFORM_

#include <stdint.h>
#include <stdarg.h>

int platform_cpu_count( void );
int platform_virt_cpuid( void );
int platform_logic_cpuid( int virt_cpuid );
int platform_phys_cpuid( int virt_cpuid );

static inline int platform_logic_cpuid_self( void ){
    return platform_logic_cpuid(platform_virt_cpuid());
}

void platform_putc( char c );
void platform_puts( const char *name );
void platform_printf( const char *fmt, ... );


#endif
