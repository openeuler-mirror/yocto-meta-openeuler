#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <printf.h>

#include "platform.h"

#define JAILHOUSE_HC_GET_CPU_COUNT           (0x80+1)
#define JAILHOUSE_HC_GET_VIRT_CPUID          (0x80+2)
#define JAILHOUSE_HC_GET_PHYS_CPUID          (0x80+3)
#define JAILHOUSE_HC_GET_LOGIC_CPUID         (0x80+4)
#define JAILHOUSE_HC_GET_RESOUECE_TABLE_ADDR (0x80+5)
#define JAILHOUSE_HC_GET_RESOUECE_TABLE_SIZE (0x80+6)

#define _LOG_INFO(fmt, args...) platform_printf(fmt "\n", ##args)
#define ARRAY_COUNT(a) (sizeof(a)/sizeof(a[0]))

int platform_cpu_count(void){
	return jailhouse_call(JAILHOUSE_HC_GET_CPU_COUNT);
}

int platform_virt_cpuid( void ){
	return jailhouse_call(JAILHOUSE_HC_GET_VIRT_CPUID);
}

int platform_logic_cpuid( int virt_cpuid ){
	return jailhouse_call_arg1(JAILHOUSE_HC_GET_LOGIC_CPUID, virt_cpuid);
}

int platform_phys_cpuid( int virt_cpuid ){
	return jailhouse_call_arg1(JAILHOUSE_HC_GET_PHYS_CPUID, virt_cpuid);
}


static unsigned long jh_get_resource_table_addr( void ){
    return jailhouse_call(JAILHOUSE_HC_GET_RESOUECE_TABLE_ADDR);
}
static unsigned long jh_get_resource_table_size( void ){
    return jailhouse_call(JAILHOUSE_HC_GET_RESOUECE_TABLE_SIZE);
}


 void platform_putc( char ch ){
    jailhouse_call_arg1(8, ch);
}

void platform_puts( const char *s ){
    while( *s ){
        platform_putc(*s);
        s++;
    }
}

void platform_printf( const char *fmt, ... ){
    char buff[64];
    va_list va;

    va_start(va, fmt);
    vsnprintf( buff, sizeof(buff), fmt, va );
    va_end(va);

    platform_puts(buff);
}

