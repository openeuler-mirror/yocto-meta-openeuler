
#ifndef _JAILHOUSE_HYPERCALL_H
#define _JAILHOUSE_HYPERCALL_H

#include <stdint.h>

#ifdef __aarch64__
	#define JAILHOUSE_CALL_INS           "hvc #0x4a48"
	#define JAILHOUSE_CALL_NUM_RESULT    "x0"
	#define JAILHOUSE_CALL_ARG1          "x1"
	#define JAILHOUSE_CALL_ARG2	         "x2"
	#define JAILHOUSE_CALL_CLOBBERED     "x3"
	typedef uint64_t __jh_arg;

#else
	#define JAILHOUSE_CALL_INS		    "hvc #0x4a48"
	#define JAILHOUSE_CALL_NUM_RESULT	"r0"
	#define JAILHOUSE_CALL_ARG1		    "r1"
	#define JAILHOUSE_CALL_ARG2		    "r2"
	#define JAILHOUSE_CALL_CLOBBERED	"r3"
	typedef uint32_t __jh_arg;
#endif

#define JAILHOUSE_HC_DEBUG_CONSOLE_PUTC 8

struct jailhouse_console {
	uint64_t address;
	uint32_t size;
	uint16_t type;
	uint16_t flags;
	uint32_t divider;
	uint32_t gate_nr;
	uint64_t clock_reg;
} __attribute__((packed));


#define COMM_REGION_GENERIC_HEADER					\
	/** Communication region magic JHCOMM */			\
	char signature[6];						\
	/** Communication region ABI revision */			\
	uint16_t revision;							\
	/** Cell state, initialized by hypervisor, updated by cell. */	\
	volatile uint32_t cell_state;					\
	/** Message code sent from hypervisor to cell. */		\
	volatile uint32_t msg_to_cell;					\
	/** Reply code sent from cell to hypervisor. */			\
	volatile uint32_t reply_from_cell;					\
	/** Holds static flags, see JAILHOUSE_COMM_FLAG_*. */		\
	uint32_t flags;							\
	/** Debug console that may be accessed by the inmate. */	\
	struct jailhouse_console console;				\
	/** Base address of PCI memory mapped config. */		\
	uint64_t pci_mmconfig_base;

struct jailhouse_comm_region {
	COMM_REGION_GENERIC_HEADER;
	uint8_t gic_version;
	uint8_t padding[7];
	uint64_t gicd_base;
	uint64_t gicc_base;
	uint64_t gicr_base;
	uint32_t vpci_irq_base;
} __attribute__((packed));

/* 获取comm_region地址 */
#define JAILHOUSE_HC_GET_COMM_REGION    (0x80+0)
/* 获取CPU个数*/
#define JAILHOUSE_HC_GET_CPU_COUNT      (0x80+1)
/* 获取虚拟CPUID, 从0开始顺序编号 */
#define JAILHOUSE_HC_GET_VIRT_CPUID     (0x80+2)
/* 获取物理CPUID, 即MPIDR寄存器值
 * ARG1: 虚拟CPUID */
#define JAILHOUSE_HC_GET_PHYS_CPUID     (0x80+3)
/* 获取逻辑CPUID, 所有CPU从0开始按顺序编号
   ARG1: 虚拟CPUID */
#define JAILHOUSE_HC_GET_LOGIC_CPUID    (0x80+4)

__jh_arg jailhouse_call(__jh_arg num);
__jh_arg jailhouse_call_arg1(__jh_arg num, __jh_arg arg1);
__jh_arg jailhouse_call_arg2(__jh_arg num, __jh_arg arg1,__jh_arg arg2);

int jh_get_virt_cpuid( void );
int jh_get_logic_cpuid( int virt_cpuid );
int jh_get_phys_cpuid( int virt_cpuid );
int jh_get_phys_cpuid_self( void );
int jh_get_logic_cpuid_self( void );
int jh_get_logic_cpunum(void);

#endif
