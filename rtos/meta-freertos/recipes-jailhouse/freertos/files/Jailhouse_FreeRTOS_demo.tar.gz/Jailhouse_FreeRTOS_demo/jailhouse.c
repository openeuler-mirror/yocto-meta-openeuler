#include <stdarg.h>
#include <stdio.h>
#include "ivsmp2p_rtt/hypercall.h"

int jh_get_virt_cpuid( void ){
	return jailhouse_call(JAILHOUSE_HC_GET_VIRT_CPUID);
}

int jh_get_logic_cpuid( int virt_cpuid ){
	return jailhouse_call_arg1(JAILHOUSE_HC_GET_LOGIC_CPUID, virt_cpuid);
}

int jh_get_phys_cpuid( int virt_cpuid ){
	return jailhouse_call_arg1(JAILHOUSE_HC_GET_PHYS_CPUID, virt_cpuid);
}

int jh_get_phys_cpuid_self( void ){
	return jh_get_phys_cpuid(jh_get_virt_cpuid());
}

int jh_get_logic_cpuid_self( void ){
	return jh_get_logic_cpuid(jh_get_virt_cpuid());
}
int jh_get_logic_cpunum(void){
	return jailhouse_call(JAILHOUSE_HC_GET_CPU_COUNT);
}

static void jh_putc( char ch ){
	jailhouse_call_arg1(JAILHOUSE_HC_DEBUG_CONSOLE_PUTC, ch);
}

void jh_printf( const char *fmt, ... ){
    static char buf[128];
    const char *pbuf;
    va_list va;
    va_start(va, fmt);
    vsnprintf( buf, 128, fmt, va );
    va_end(va);

    pbuf = buf;
    while( *pbuf ){
        jh_putc(*pbuf);
        pbuf++;
    }
}

__jh_arg jailhouse_call(__jh_arg num)
{
    register int num_result asm(JAILHOUSE_CALL_NUM_RESULT) = num;

	asm volatile(
		JAILHOUSE_CALL_INS
		: "+r" (num_result)
		: : "memory", JAILHOUSE_CALL_ARG1, JAILHOUSE_CALL_ARG2,
		    JAILHOUSE_CALL_CLOBBERED);
	return num_result;
}

__jh_arg jailhouse_call_arg1(__jh_arg num, __jh_arg arg1)
{
    register int num_result asm(JAILHOUSE_CALL_NUM_RESULT) = num;
    register int __arg1 asm(JAILHOUSE_CALL_ARG1) = arg1;

    asm volatile(
        JAILHOUSE_CALL_INS
        : "+r" (num_result), "+r" (__arg1)
        : : "memory", JAILHOUSE_CALL_ARG2, JAILHOUSE_CALL_CLOBBERED);
        return num_result;
}

__jh_arg jailhouse_call_arg2(__jh_arg num, __jh_arg arg1, __jh_arg arg2)
{
	register __jh_arg num_result asm(JAILHOUSE_CALL_NUM_RESULT) = num;
	register __jh_arg __arg1 asm(JAILHOUSE_CALL_ARG1) = arg1;
	register __jh_arg __arg2 asm(JAILHOUSE_CALL_ARG2) = arg2;

	asm volatile(
		JAILHOUSE_CALL_INS
		: "+r" (num_result), "+r" (__arg1), "+r" (__arg2)
		: : "memory", JAILHOUSE_CALL_CLOBBERED);
	return num_result;
}


