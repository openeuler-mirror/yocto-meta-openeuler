const unsigned short int *__ctype_b;
